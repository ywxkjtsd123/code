open(IN,"F:\\yx.VQ.list.txt");
while($line=<IN>){
	chomp $line;
	$hash{$line}=1;
}
close IN;


$/=">";
open(IN,"F:\\yx.cds.fa");
while($line=<IN>){
	chomp $line; 
	@a=split(/\n/,$line,2);
	$name=$a[0];
	$a[1]=~s/\n//g;
	$seq=$a[1];
	$length=length$seq;
	@j=split(/\s+/,$name);
	$j[0]=~/(\S+)/; #Match based on you own data
	$gene=$1;
	if($hash{$gene}  && !$hs{$gene}){
		$hs{$gene}=$seq;
		$hs1{$gene}=$length;
	}
	if($hash{$gene}  && $hs{$gene}){
		if($length > $hs1{$gene}){
			$hs{$gene}=$seq;
			$hs1{$gene}=$length;
		}
	}
}
close IN;

open(OUT,">F:\\yx.VQ.cds.fa");
foreach $key (keys %hs) {
	print OUT ">$key\n$hs{$key}\n";
}
close OUT;