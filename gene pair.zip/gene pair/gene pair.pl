use Math::BigFloat;
open(IN,"F:\\yx.blast.txt");
open(OUT,">F:\\yx.VQ.pair.txt");
while ($line=<IN>) {
	chomp $line;
	@a=split(/\s+/,$line);
	if($line=~/hits\s+found/){
		$length=0;
		$tick=0;
		next;
	}
	if (@a==12 && ($a[0] eq $a[1]) && $tick==0) {
		$length=$a[3];
		$tick=1;
		next;
	}
	if (@a==12 && $a[3] && $length) {
		$evalue = new Math::BigFloat $a[10];
		$t=new Math::BigFloat '1e-15';
		if (($a[2]>=75) && ((100*$a[3]/$length)>=75) && ($evalue<$t)) {
			$new=$a[0]."-".$a[1];
			$hash{$new}=1;
		}
	}
}
foreach $key (sort keys %hash) {
	@b=split(/-/,$key);
	$rev=$b[1]."-".$b[0];
	if ($hash{$rev}==1  && $hash{$key}==1) {
		$hash{$key}=2;
		$hash{$rev}=2;
		print OUT "$b[0]\t$b[1]\n";
	}
}

close IN;
close OUT;